package com.umg.ers.analytics.spotify.helper;

public class Credentials {

	private String clientId;
	private String clientSecreKey;
	
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getClientSecreKey() {
		return clientSecreKey;
	}
	public void setClientSecreKey(String clientSecreKey) {
		this.clientSecreKey = clientSecreKey;
	}
	
	
	
}
