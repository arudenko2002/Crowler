package com.umg.ers.analytics.spotify.playlist.model;

public class SimpleTracks {
	
	private String currentPosition;
	private String plays;
	private String previous_position;
	

}
