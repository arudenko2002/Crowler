package com.umg.ers.analytics.spotify.charts.model;

import java.util.List;

public class AvailableMarkets {
	
	private List<String> countries;

	public List<String> getCountries() {
		return countries;
	}

	public void setCountries(List<String> countries) {
		this.countries = countries;
	}
	
	

}
