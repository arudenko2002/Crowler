package com.umg.ers.analytics.spotify.playlist.model;

public class Categories {

	private Page<SimpleCategory> categories;

	public Page<SimpleCategory> getCategories() {
		return categories;
	}

	public void setCategories(Page<SimpleCategory> categories) {
		this.categories = categories;
	}

	  
	
}
