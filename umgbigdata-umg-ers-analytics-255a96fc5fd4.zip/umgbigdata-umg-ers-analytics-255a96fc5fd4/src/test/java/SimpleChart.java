import java.util.List;


public class SimpleChart {
	
	private String title;
	private String description;
	private List<String> isrc;
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public List<String> getIsrc() {
		return isrc;
	}
	public void setIsrc(List<String> isrc) {
		this.isrc = isrc;
	}
	
	

}
